import os
from app.utils.pinecone_utils import index_documents

def load_and_index_documents():
    base_path = "/home/ubuntu/ds-rpc-01/ds-rpc-01/resources/data"
    
    # Define a mapping from directory names to Pinecone collection names
    # This assumes that each subdirectory under resources/data corresponds to a collection
    collection_mapping = {
        "finance": "finance",
        "marketing": "marketing",
        "hr": "hr",
        "engineering": "engineering",
        "general": "general"
    }

    for dir_name, collection_name in collection_mapping.items():
        dir_path = os.path.join(base_path, dir_name)
        documents = []
        if os.path.exists(dir_path) and os.path.isdir(dir_path):
            for filename in os.listdir(dir_path):
                file_path = os.path.join(dir_path, filename)
                if os.path.isfile(file_path):
                    with open(file_path, "r", encoding="utf-8") as f:
                        documents.append(f.read())
            if documents:
                print(f"Indexing {len(documents)} documents into collection: {collection_name}")
                index_documents(collection_name, documents)
            else:
                print(f"No documents found in {dir_path}")
        else:
            print(f"Directory not found: {dir_path}")

if __name__ == "__main__":
    load_and_index_documents()


