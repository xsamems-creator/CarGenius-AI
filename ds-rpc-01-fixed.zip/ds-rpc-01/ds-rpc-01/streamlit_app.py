# streamlit_app.py
import streamlit as st
# Removed: from fastapi import FastAPI (unused)
from app.chatbot.rag import process_query

st.title("FinSolve Technologies Chatbot")

query = st.text_input("Enter your query:")
role = st.selectbox(
    "Select your role:", 
    ["finance", "marketing", "hr", "engineering", "executive", "employee"]
)

if st.button("Submit"):
    response = process_query(query, role)
    st.write(f"Response: {response}")