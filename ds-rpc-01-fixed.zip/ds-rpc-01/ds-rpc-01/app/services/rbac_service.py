# services/rbac_service.py
def get_allowed_collections(role):
    role_to_collections = {
        "finance": ["finance"],
        "marketing": ["marketing"],
        "hr": ["hr"],
        "engineering": ["engineering"],
        "executive": ["finance", "marketing", "hr", "engineering"],
        "employee": ["general"]
    }
    return role_to_collections.get(role, [])


def filter_data_by_role(data, role):
    allowed_collections = get_allowed_collections(role)
    return {k: v for k, v in data.items() if k in allowed_collections}