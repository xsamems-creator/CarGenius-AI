# utils/qdrant_utils.py
from qdrant_client import QdrantClient
from qdrant_client.http.models import PointStruct
from sentence_transformers import SentenceTransformer

from dotenv import load_dotenv
import os

load_dotenv()
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
QDRANT_API_KEY = os.getenv("QDRANT_API_KEY")
QDRANT_URL = os.getenv("QDRANT_URL")

client = QdrantClient(
    url=QDRANT_URL,
    api_key=QDRANT_API_KEY,
    prefer_grpc=True
)

model = SentenceTransformer('all-MiniLM-L6-v2')


def embed_text(text):
    return model.encode([text]).tolist()[0]


def index_documents(collection_name, documents):
    client.recreate_collection(
        collection_name=collection_name,
        vectors_config={
            "size": 384,  # Embedding size
            "distance": "Cosine"
        }
    )
    points = [
        PointStruct(id=i, vector=embed_text(doc), payload={"text": doc})
        for i, doc in enumerate(documents)
    ]
    client.upsert(collection_name=collection_name, points=points)


def search_documents(collection_name, query, top_k=5):
    query_vector = embed_text(query)
    hits = client.search(
        collection_name=collection_name,
        query_vector=query_vector,
        limit=top_k
    )
    return [hit.payload["text"] for hit in hits]