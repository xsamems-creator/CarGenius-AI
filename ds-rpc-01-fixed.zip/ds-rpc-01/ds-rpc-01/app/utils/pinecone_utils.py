import os
import uuid
from typing import List, Dict, Any
from dotenv import load_dotenv
import google.generativeai as genai
from pinecone import Pinecone, ServerlessSpec

load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")

genai.configure(api_key=GEMINI_API_KEY)

# Initialize Pinecone with new API
pc = Pinecone(api_key=PINECONE_API_KEY)


def embed_text(text):
    """Convert text to embeddings using Gemini's embedding model"""
    model = 'models/embedding-001'
    return genai.embed_content(model=model, content=text)["embedding"]


def index_documents(collection_name, documents):
    """Index documents in Pinecone"""
    # Check if index exists, if not create it
    if collection_name not in [index.name for index in pc.list_indexes()]:
        pc.create_index(
            name=collection_name,
            dimension=768,  # Embedding size for Gemini's embedding-001
            metric="cosine",
            spec=ServerlessSpec(cloud='aws', region='us-east-1') # Changed region to us-east-1
        )
    
    # Connect to the index
    index = pc.Index(collection_name)
    
    # Prepare vectors for upsert
    vectors = []
    for i, doc in enumerate(documents):
        vector = embed_text(doc)
        vectors.append({
            'id': str(uuid.uuid4()),  # Use UUID for unique IDs
            'values': vector,
            'metadata': {'text': doc}
        })
    
    # Upsert in batches of 100 to avoid hitting API limits
    batch_size = 100
    for i in range(0, len(vectors), batch_size):
        batch = vectors[i:i+batch_size]
        index.upsert(vectors=batch)


def search_documents(collection_name, query, top_k=5):
    """Search for similar documents in Pinecone"""
    # Connect to the index
    try:
        index = pc.Index(collection_name)
    except Exception as e:
        print(f"Error connecting to index {collection_name}: {e}")
        return []
    
    # Generate query vector
    query_vector = embed_text(query)
    
    # Search in Pinecone
    try:
        results = index.query(
            vector=query_vector,
            top_k=top_k,
            include_metadata=True
        )
        
        # Extract text from results
        return [match['metadata']['text'] for match in results['matches']]
    except Exception as e:
        print(f"Error searching in index {collection_name}: {e}")
        return []

