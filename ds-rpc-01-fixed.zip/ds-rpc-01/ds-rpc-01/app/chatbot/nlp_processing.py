# nlp_processing.py
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from dotenv import load_dotenv
import os

load_dotenv()
api_key = os.getenv("GEMINI_API_KEY")

# Instantiate Gemini embeddings and chat LLM
gemini_embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001", google_api_key=api_key)
chatllm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", google_api_key=api_key, temperature=0.6, convert_system_message_to_human=True)

def generate_response(prompt):
    # Gemini expects a list of messages or a single prompt
    response = chatllm.invoke(prompt)
    # The returned response is typically an AIMessage object, extract content
    return response.content

