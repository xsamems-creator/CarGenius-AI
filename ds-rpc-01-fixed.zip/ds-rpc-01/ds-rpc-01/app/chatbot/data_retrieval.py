import os
import csv
from typing import Dict, List


# Define the base path where all departmental data is stored
DATA_DIR = "resources/data"


def read_markdown_file(file_path: str) -> str:
    """Reads and converts Markdown file to plain text."""
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()


def read_csv_file(file_path: str) -> List[Dict]:
    """Reads CSV file and returns list of rows as dictionaries."""
    with open(file_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return [row for row in reader]


def load_department_data(department: str) -> List[Dict]:
    """
    Load all files from a specific department folder.
    Returns a list of dicts containing metadata and content.
    """
    department_path = os.path.join(DATA_DIR, department.lower())
    if not os.path.exists(department_path):
        return []

    documents = []
    for filename in os.listdir(department_path):
        file_path = os.path.join(department_path, filename)

        # Skip hidden/system files
        if filename.startswith("."):
            continue

        try:
            if filename.endswith(".md"):
                content = read_markdown_file(file_path)
                file_type = "markdown"
            elif filename.endswith(".csv"):
                content = read_csv_file(file_path)
                file_type = "csv"
            else:
                continue  # Skip unsupported file types

            documents.append(
                {
                    "department": department,
                    "filename": filename,
                    "file_type": file_type,
                    "content": content,
                    "source": file_path
                }
            )
        except Exception as e:
            print(f"Error reading {file_path}: {e}")

    return documents


def get_all_documents() -> Dict[str, List[Dict]]:
    """
    Retrieve all documents grouped by department.
    Example keys: 'finance', 'marketing', 'hr', 'engineering', 'general'
    """
    departments = ["finance", "marketing", "hr", "engineering", "general"]
    all_docs = {}

    for dept in departments:
        docs = load_department_data(dept)
        all_docs[dept] = docs

    return all_docs


def search_in_department(query: str, department: str, top_k=3) -> List[Dict]:
    """
    Search for relevant documents in a specific department based on query.
    This is a simple keyword match for now; 
    later can be replaced with vector search.
    """
    docs = load_department_data(department)
    results = []

    for doc in docs:
        content = str(doc["content"]).lower()
        if query.lower() in content:
            results.append(doc)
            if len(results) >= top_k:
                break

    return results


def get_file_content_by_name(department: str, filename: str) -> Dict:
    """
    Retrieve the content of a specific file by name within a department.
    """
    docs = load_department_data(department)
    for doc in docs:
        if doc["filename"] == filename:
            return doc
    return {"error": "File not found"}

