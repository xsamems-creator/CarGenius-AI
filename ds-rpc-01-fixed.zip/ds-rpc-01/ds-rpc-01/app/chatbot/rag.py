# chatbot/rag.py
from app.utils.pinecone_utils import search_documents
from app.chatbot.nlp_processing import generate_response
from app.services.rbac_service import get_allowed_collections


def process_query(query, role):
    # Step 1: Retrieve relevant documents based on role
    allowed_collections = get_allowed_collections(role)
    retrieved_docs = {}
    for collection in allowed_collections:
        retrieved_docs[collection] = search_documents(collection, query, top_k=3)

    # Step 2: Augment query with retrieved documents
    augmented_query = f"Based on the following documents:\n\n"
    for collection, docs in retrieved_docs.items():
        augmented_query += f"--- {collection.capitalize()} ---\n"
        for doc in docs:
            augmented_query += f"{doc}\n\n"

    augmented_query += f"Answer the following question: {query}"

    # Step 3: Generate response using Groq
    response = generate_response(augmented_query)
    return response